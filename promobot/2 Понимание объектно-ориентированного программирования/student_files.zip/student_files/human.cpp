#include "human.hpp"

Human::Human(std::string p_name, int p_age)
{
    name = p_name;
    age = p_age;
}
