#include <string>

class Human
{
    public:
        std::string name;
        int age;

        Human(std::string p_name, int p_age);

};