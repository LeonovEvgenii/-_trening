#include "student.cpp"

int main()
{
    Student student("вася", 16, 3.4);

    return 0;
}